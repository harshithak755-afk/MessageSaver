from django.shortcuts import render, redirect, get_object_or_404
from .forms import MessageForm
from .models import Message

# Create
def message_create(request):
    form = MessageForm(request.POST or None)
    if form.is_valid():
        Message.objects.create(**form.cleaned_data)
        return redirect('list')
    return render(request, "form.html", {"form": form})

# Read
def message_list(request):
    messages = Message.objects.all()
    return render(request, "list.html", {"messages": messages})

# Update
def message_update(request, id):
    msg = get_object_or_404(Message, id=id)
    form = MessageForm(request.POST or None, initial={
        'name': msg.name,
        'email': msg.email,
        'message': msg.message
    })
    if form.is_valid():
        msg.name = form.cleaned_data['name']
        msg.email = form.cleaned_data['email']
        msg.message = form.cleaned_data['message']
        msg.save()
        return redirect('list')
    return render(request, "form.html", {"form": form})

# Delete
def message_delete(request, id):
    msg = get_object_or_404(Message, id=id)
    msg.delete()
    return redirect('list')
