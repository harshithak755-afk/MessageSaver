from django.contrib import admin
from django.urls import path
from contact import views 

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', views.message_create, name='create'),
    path('list/', views.message_list, name='list'),
    path('edit/<int:id>/', views.message_update, name='edit'),
    path('delete/<int:id>/', views.message_delete, name='delete'),
]
